function Kappa = straight(distance)

Kappa(1:floor(distance)) = 0;
end

