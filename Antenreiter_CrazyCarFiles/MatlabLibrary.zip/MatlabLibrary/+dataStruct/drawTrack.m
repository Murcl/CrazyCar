function drawTrack(data,g,periodic)

%     if mod(data.lengthActual,periodic) == 0
%         for k = 1:5
%             g.XDataSource = 'data.wall(1,:,k)';
%             g.YDataSource = 'data.wall(2,:,k)';
% %             set(g.Children.Children,'XData',data.wall(1,:,k));
% %             set(g.Children.Children,'YData',data.wall(2,:,k))
%             drawnow;
%         end
%     end


end

