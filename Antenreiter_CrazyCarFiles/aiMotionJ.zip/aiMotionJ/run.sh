java -Djava.library.path=. -jar dist/aiMotionJ.jar
